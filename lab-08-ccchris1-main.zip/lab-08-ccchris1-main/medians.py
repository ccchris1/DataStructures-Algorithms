from heap import Heap
from typing import Iterable

def running_medians(iterable: Iterable[float]) -> list[float]:
    #so it seems like you have to check the median every time a val is appended and you have to sort every time you append
    #step 1: create a max heap and a min heap based on some condition. you keep appending to min and max. if the len of both are the
    #same, you take the average of the peak of min and max
    #Start by doing a min heap or max heap, doesnt matter how you start. len(maxH) == 0. you dont have to rewrite, just use the code from the previous one, its already imported
    #also do len(minH) == 0, when you append update the len accordingly, make another list medians and append to it
    #if newValue > runningMedian -> append to minHeap , else: append to maxHeap
    #in the end the heaps can only differ in length by 1 or 0. if its greater, you pop the head of the one that has the bigger length, and transfer it to the other heap

    #the condition that checks is gonna be something like if len(minH) - len(max) == 1 or 0: -> do something, else: some transfer of heaps
    #when you read both heaps, it should read in a sorted order, draw both heaps, start reading from bottom of maxH and go in order to minH, it should be sorted
    #you only need to all add, because it already adds it in the correct order

    #PSUEDO:

    minH = Heap(lambda x: -x)
    maxH = Heap(lambda x: x)
    median = []
    pointer = 0

    minH.add(iterable[0])
    median.append(iterable[0])

    for num in range(1, len(iterable)):
        if iterable[num] < median[pointer]:
            maxH.add(iterable[num])
        elif iterable[num] > median[pointer]:
            minH.add(iterable[num])

        if len(maxH.data) > len(minH.data) + 1:
            minH.add(maxH.pop())
        elif len(minH.data) > len(maxH.data) + 1:
            maxH.add(minH.pop())

        if len(maxH.data) == len(minH.data):
            median.append((minH.peek() + maxH.peek()) / 2)
        elif len(maxH.data) > len(minH.data):
            median.append(maxH.peek())
        else:
            median.append(minH.peek())

        pointer += 1
    return median
