from typing import Any

class Heap:
    def __init__(self, key=lambda x:x):
        self.data = []
        self.key  = key

    
    def __parent__(idx):
        return (idx-1)//2

    
    def __left__(idx):
        return 2*idx+1

    
    def __right__(idx):
        return 2*idx+2

    
    def __heapify__(self):
        #the goal is to implement other ways to use heapify other than just to check for max_heap
        #idea: check for each different key, make a function for each of them, check for each different scenario with a if statement
        idx = 0
        while idx < len(self.data):
            lidx = Heap().__left__(idx)
            ridx = Heap().__right__(idx)
            maxidx = idx
            maxValue = self.key(self.data[maxidx])
            if lidx < len(self.data) and self.key(self.data[lidx]) > maxValue:
                maxidx = lidx
                maxValue = self.key(self.data[lidx])
            if ridx < len(self.data) and self.key(self.data[ridx]) > maxValue:
                maxidx = ridx
                maxValue = self.key(self.data[ridx])
            if maxidx != idx:
                self.data[idx], self.data[maxidx] = self.data[maxidx], self.data[idx]
                idx = maxidx
            else:
                break

    
    def add(self, x: Any) -> None:
        self.data.append(x)
        idx = len(self.data) - 1
        pidx = Heap().__parent__(idx)
        while idx > 0 and self.key(self.data[idx]) > self.key(self.data[pidx]):
            self.data[idx], self.data[pidx] = self.data[pidx], self.data[idx]
            idx = pidx
            pidx = Heap().__parent__(idx)

        
    def peek(self) -> Any:
        return self.data[0]


    def pop(self) -> Any:
        val = self.data[0]
        self.data[0] = self.data[-1]
        del self.data[-1]
        if len(self.data) > 0:
            self.__heapify__()
        return val

    
    def __bool__(self) -> bool:
        return len(self.data) > 0


    def __len__(self) -> int:
        return len(self.data)


    def __repr__(self) -> str:
        return repr(self.data)
