import numpy as np
from typing import Any
from collections import deque


class Queue:
    def __init__(self, limit=10):
        self.data = np.empty(limit, dtype=object)
        self.head = -1
        self.tail = -1
        self.count = 0

    
    def empty(self):
        return self.count == 0

    def __bool__(self):
        return not self.empty()
   

    def __str__(self):
        if not(self):
            return ''
        return ', '.join(str(x) for x in self)
    

    def __repr__(self):
        return str(self)
    
   
    ## Don't change the above code!
    
    def enqueue(self, val: Any): #when the queue is emptied its head and tail attributes are reset to -1.
        #enqueue means to add to the end of the array
        if self.count >= len(self.data):
            raise RuntimeError
        if self.count == 0:
            self.head = 0
        self.tail = (self.tail + 1) % len(self.data) #this is ensuring that when self.tail reaches len(self.data) it wraps and goes back to 0
        
        self.data[self.tail] = val
        self.count += 1
    def dequeue(self) -> Any: #when dequeuing an item, its slot in the array is reset to None
        assert len(self.data) > 0
        val = self.data[self.head]
        self.data[self.head] = None
        self.head = (self.head + 1) % len(self.data)
        self.count -= 1

        if len(self.data) == 0:
            self.head = -1
            self.tail = -1
        if all(v is None for v in self.data):
            self.head = -1

        print(self.data)
        return val

    def resize(self, newsize: int):
        assert len(self.data) < newsize
        #self.head = 0
        
        index = self.head
        newArr = np.empty(newsize, dtype=object)
        for item in range(newsize):
            newArr[item] = self.data[index]
            index = (index + 1) % self.count
        self.data = newArr
        self.count = 5
        self.head = 0  #the problem is when it tries to enqueue, it is not doing it because it is getting a runtime error when it tries
        self.tail = self.count - 1
        print(self.data)


    def __iter__(self):
        index = self.head
        num_elements = self.count
        while num_elements > 0:
            yield self.data[index]
            index = (index + 1) % self.count  # circular increment
            num_elements -= 1

