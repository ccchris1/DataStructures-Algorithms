from stack import Stack


def check_delimiters(expr: str, delims: dict[str,str]) -> bool:
    stack = Stack()
    inside_quotes = False
    current_quote = None  

    for char in expr:
        if char in delims and delims[char] == char:  # If it's a quote (same opening and closing)
            if inside_quotes and current_quote == char:  # Closing quote
                inside_quotes = False
                current_quote = None
                stack.pop()  # Pop the matching opening quote
            elif not inside_quotes:  # Opening quote
                inside_quotes = True
                current_quote = char
                stack.push(char)  # Push the opening quote
            continue  # Skip further processing for quotes
        
        # Skip delimiter checking when inside quotes
        if inside_quotes:
            continue
        
        # Handle non-quote delimiters (like parentheses)
        if char in delims:  # Opening delimiter
            stack.push(char)
        elif char in delims.values():  # Closing delimiter
            if stack.empty():  # Mismatch: no opening delimiter for this one
                return False
            top = stack.pop()
            if delims[top] != char:  # Mismatch: closing delimiter doesn't match
                return False

    # At the end, stack should be empty (all delimiters matched)
    return stack.empty()

def precedence(op):
    """Return the precedence level of an operator."""
    if op in ('+', '-'):
        return 1
    elif op in ('*', '/'):
        return 2
    return 0

def infix_to_postfix(expr: str) -> str:
    lst = []
    stack = Stack()

    for t in expr.split():
        if t.isnumeric():
            lst.append(t)
        elif t == '(':  # If T is a left parenthesis, push it onto S
            stack.push(t)
        elif t == ')':  # If T is a right parenthesis, pop until '('
            while not stack.empty() and stack.peek() != '(':
                lst.append(stack.pop())
            stack.pop()  # Remove the left parenthesis from the stack
        else:  # T is an operator
            while not stack.empty() and precedence(stack.peek()) >= precedence(t):
                lst.append(stack.pop())
            stack.push(t)  # Push the current operator onto the stack

    # Pop all the remaining operators in the stack
    while not stack.empty():
        lst.append(stack.pop())

    return ' '.join(lst)
