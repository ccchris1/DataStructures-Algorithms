[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/DB5sx4Df)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=16538959)
# Lab: Ordered Hashtable

## Overview

For this assignment you will complete the implementation of the hashtable data structure, which exposes an API mirroring that of the built-in Python `dict`. When iterating over its contents (supported by the `__iter__`, `keys`, `values`, and `items` methods), your updated implementation will also reflect the order in which key/value pairs were originally inserted into the hashtable. In order to maintain $O(1)$ runtime complexity, you will need to implement the two-tiered list system.

The operations you will implement are listed alongside their descriptions below (`h` refers to a hashtable):

| Operation | Description |
|-----------|-------------|
| `h[k] = v` | If `h` does not contain key `k`, a new `k`&rightarrow;`v` mapping is added, else the value for key `k` is updated to `v`. |
| `h[k]`    | If `h` contains key `k`, the corresponding value is returned, else a `KeyError` is raised. |
| `del h[k]` | If `h` contains key `k`, it is removed along with its value, else a `KeyError` is raised. Note that if `k` is re-inserted at some later point it is considered a new key (for ordering purposes). |
| `k in h` | Returns `True` if key `k` is in `h`. |
| `len(h)` | Returns the number of keys in `h`. |
| `iter(h)` | Returns an iterator over all the keys in `h`, in the order they were added. |
| `h.keys()` | (Same as above) |
| `h.values()` | Returns an iterator over all the values in `h`, in the order they were added. |
| `h.items()` | Returns an iterator over all the key/value pairs (as tuples) in `h`, in the order they were added. |

Your hashtable will be provided with the initial number of buckets on creation (i.e., in `__init__`); your implementation must heed this value, as there may be performance ramifications if it does not.

## Implementation Details

All your code will go into `hashtable.py`, where we include stubs for all the methods you will need to implement. You may add additional methods, but you may not change the signatures of the existing methods. You may assume that all keys are hashable.
