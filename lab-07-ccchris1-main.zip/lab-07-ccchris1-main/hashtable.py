class OrderedHashtable:
    class Node:
        """This class is used to create nodes in the singly linked "chains" in
        each hashtable bucket."""
        def __init__(self, index, next=None):
            # don't rename the following attributes!
            self.index = index
            self.next = next
        
    def __init__(self, n_buckets=1000):
        # the following two variables should be used to implement the 
        # "two-tiered" ordered hashtable -- 
        # don't rename them!
        self.indices = [None] * n_buckets
        self.entries = []
        self.count = 0
        
    def __getitem__(self, key):
        bucket_idx = hash(key) % len(self.indices)
        n = self.indices[bucket_idx]
        while n:
            s = self.entries[n.index]
            if s[0] == key:   
                return s[1]
            else:
                n = n.next
        else:
            raise KeyError()
    
    def __setitem__(self, key, val):
        #check if key exists, if it does, update entries only - no hashtable yet, if it doesnt append [k,v] to entries to get an index, create a node with appropritate index--i believe the index is len(entries) - 1 and PREPEND it to the appropritate index
        bucket_idx = hash(key) % len(self.indices)
        n = self.indices[bucket_idx]
        while n:
            s = self.entries[n.index]
            if s[0] == key:
                self.entries[n.index] = ((key,val))
                return
            n = n.next

        self.entries.append((key,val))
        new_index = len(self.entries) - 1

        new_node = self.Node(new_index, next = self.indices[bucket_idx])
        self.indices[bucket_idx] = new_node
        self.count += 1
    
    def __delitem__(self, key): #when you delete from entries, DO NOT pop it from the list, change the value in the list to None,
        #step 1: check if key exists, prev.next = curr.next, make corresponding key:val in entries list to None, actually it might be index = None.
        bucket_idx = hash(key) % len(self.indices)
        n = self.indices[bucket_idx]
        prev = None

        while n:
            s = self.entries[n.index]
            if s[0] == key:
                if prev is not None:
                    prev.next = n.next #n is current
                else:
                    self.indices[bucket_idx] = n.next #this only executes once, when prev is none which should only be one time
                self.count -= 1
                self.entries[n.index] = None
                return
            prev = n
            n = n.next

        raise KeyError()
        
    def __contains__(self, key):
        bucket_idx = hash(key) % len(self.indices)
        n = self.indices[bucket_idx]

        while n:
            s = self.entries[n.index]
            if s[0] == key:
                return True
            n = n.next
        
        return False
        
    def __len__(self):
        return self.count
    
    def __iter__(self):
        for key in self.entries:
            if key is not None:
                yield key[0]
        
    def keys(self):
        for key, val in self.entries:
            if key is not None:
                yield key[0]
    
    def values(self):
        for key, val in self.entries:
            if key is not None:
                yield key[1]
                
    def items(self):
        for entry in self.entries:
            if entry is not None:
                yield entry
                
    def __str__(self):
        return str(len(self.entries))
            
    def __repr__(self):
        return str(self.entries)
