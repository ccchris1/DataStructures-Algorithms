import random

ROMEO_SOLILOQUY = """
        But, soft! what light through yonder window breaks?
        It is the east, and Juliet is the sun.
        Arise, fair sun, and kill the envious moon,
        who is already sick and pale with grief, 
        That thou her maid art far more fair than she:
        be not her maid, since she is envious;
        her vestal livery is but sick and green
        and none but fools do wear it; cast it off.
        It is my lady, O, it is my love! 
        O, that she knew she were!
        She speaks yet she says nothing: what of that?
        Her eye discourses; I will answer it.
        I am too bold, 'tis not to me she speaks:
        two of the fairest stars in all the heaven, 
        having some business, do entreat her eyes
        to twinkle in their spheres till they return.
        What if her eyes were there, they in her head?
        The brightness of her cheek would shame those stars,
        as daylight doth a lamp; her eyes in heaven 
        would through the airy region stream so bright
        that birds would sing and think it were not night.
        See, how she leans her cheek upon her hand!
        O, that I were a glove upon that hand,
        that I might touch that cheek!"""


def compute_ngrams(toks, n=2):
    ngramDictionary = {}
    listOfTuples = [toks[i: i+n] for i in range(0, len(toks), 1)]
    for lst in listOfTuples:
        if len(listOfTuples) % n >= 1:
            listOfTuples.pop(-1)

    for j in listOfTuples:
        firstKey = j[0]
        if firstKey in ngramDictionary:
            ngramDictionary[firstKey] += [tuple(j[1:n])]
        else:
            ngramDictionary[firstKey] = [tuple(j[1:n])]

    return ngramDictionary



def gen_passage(ngram_dict, length=100):
    lst = []
    key = random.choice(sorted(ngram_dict.keys()))
    lists = ngram_dict[key]
    random_select = random.choice(lists)

    lst.append(key)
    lst += list(random_select)

    while length >= len(lst):
        if lst[-1] in ngram_dict:
            lists = ngram_dict[lst[-1]]
            random_select = random.choice(lists)
            lst += random_select
        else:
            choice = random.choice(sorted(ngram_dict.keys()))
            lists = ngram_dict[choice]
            random_select = random.choice(lists)
            lst.append(choice)
            lst += random_select
    
    return " ".join(lst[:length])

