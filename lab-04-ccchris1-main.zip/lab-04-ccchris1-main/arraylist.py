import numpy as np

class ArrayList:
    def __init__(self):
        self.data = np.empty(1, dtype=object)
        self.size = 0

    def _resize(self, new_capacity):
        """Resize the internal array to new_capacity"""
        new_array = np.empty(new_capacity, dtype=object)
        for i in range(self.size):
            new_array[i] = self.data[i]
        self.data = new_array

        
    ### subscript-based access ###

    def __getitem__(self, idx):
        """Implements `x = self[idx]`"""
        if idx < 0:
            if idx >= -self.size:
                idx = self.size + idx
            else:
                raise IndexError()
        if not 0 <= idx < self.size:
            raise IndexError()
        return self.data[idx]

    def __setitem__(self, idx, value):
        """Implements `self[idx] = x`"""
        if idx < 0:
            if idx >= -self.size:
                idx = self.size + idx
            else:
                raise IndexError()
        if not 0 <= idx < self.size:
            raise IndexError()
        
        if idx > self.size:
            raise IndexError()
        
        item = self.data[idx] = value
        return item

    def __delitem__(self, idx):
        """Implements `del self[idx]`"""
        if idx < 0:
            if idx >= -self.size:
                idx = self.size + idx
            else:
                raise IndexError()
        if not 0 <= idx < self.size:
            raise IndexError()

        for i in range(idx, self.size - 1):
            self.data[i] = self.data[i + 1]
            
        self.data[self.size - 1] = None
        self.size -= 1
                        

    ### stringification ###

    def __str__(self):
        """Implements `str(self)`. Returns '[]' if the list is empty, else
        returns `str(x)` for all values `x` in this list, separated by commas
        and enclosed by square brackets. E.g., for a list containing values
        1, 2 and 3, returns '[1, 2, 3]'."""
        output = '['
        if self.size > 0:
            output = output + str(self.data[0])
            for i in range(1, self.size):
                output = output + ", " + str(self.data[i])
            output = output + ']'

        else:
            output = '[]'
        
        return output

    def __repr__(self):
        """Implements `repr(self)`. Similar to `__str__`, but represents the
        list as an expression that could be evaluated to reproduce the list."""
        output = '['
        if self.size > 0:
            output = output + str(self.data[0])
            for i in range(1, self.size):
                output = output + ", " + str(self.data[i])
            output = output + ']'

        else:
            output = '[]'
        return output

    ### single-element manipulation ###

    def append(self, value):
        """Appends value to the end of this list."""
        if self.size == len(self.data):
            nsize = 2 * len(self.data)
            ndata = np.empty(nsize, dtype=object)
            for i in range(len(self.data)):
                ndata[i] = self.data[i]
            self.data = ndata
        self.data[self.size] = value
        self.size += 1

    def insert(self, idx, value):
        """Inserts value at position idx, shifting the original elements 
        down the list, as needed. Note that inserting a value at len(self) ---
        equivalent to appending the value --- is permitted."""
        if idx < 0:
            idx = self.size + idx
    
        if idx < 0 or idx > self.size:
            raise IndexError
        
        if self.size == len(self.data):
            self._resize(len(self.data) + 1)

        for i in range(self.size, idx, -1):
            self.data[i] = self.data[i - 1]
        
        self.data[idx] = value
        self.size += 1
        #newSize = len(self.data) + 1
        #newArr = np.empty(newSize, dtype=object)

        

    def pop(self, idx=-1):
        """Deletes and returns the element at idx (which is the last element,
        by default)."""
        if idx < 0:
            idx = self.size + idx
        if idx < 0 or idx > self.size:
            raise IndexError

        value = self.data[idx]

        for i in range(idx, self.size - 1):
            self.data[i] = self.data[i + 1]

        self.data[self.size - 1] = None

        self.size -= 1

        return value
        
    def remove(self, value):
        """Removes the first (closest to the front) instance of value from the
        list. Raises a ValueError if value is not found in the list."""
        for i in range(self.size):
            if self.data[i] == value:
                for j in range(i, self.size - 1):
                    self.data[j] = self.data[j + 1]
                
                self.data[self.size - 1] = None
                self.size -= 1

                return
                
        raise ValueError


    ### predicates (T/F queries) ###

    def __eq__(self, other):
        """Returns True if this ArrayList contains the same elements (in order)
        as other. If other is not an ArrayList, returns False."""
        for i in range(len(self.data)):
            if other[i] == self.data[i]:
                return True
        return False

    def __contains__(self, value):
        """Implements `val in self`. Returns true if value is found in this 
        list."""
        for i in range(self.size):
            if self.data[i] == value:
                return True

        return False


    ### queries ###

    def __len__(self):
        """Implements `len(self)`"""
        return self.size

    def min(self):
        """Returns the minimum value in this list."""
        return min(self.data)

    def max(self):
        """Returns the maximum value in this list."""
        return max(self.data)

    def index(self, value, i=0, j=None):
        """Returns the index of the first instance of value encountered in
        this list between index i (inclusive) and j (exclusive). If j is not
        specified, search through the end of the list for value. If value
        is not in the list, raise a ValueError."""

        if value not in self.data:
            raise ValueError

        if j == None:
            for i in range(i, len(self.data)):
                if self.data[i] == value:
                    return i

        else:
            if j < 0:
                j = self.size + j
            if j < 0 or j > self.size:
                raise IndexError
            if i < 0 or i >= self.size or j < 0 or j > self.size:
                raise IndexError
            for i in range(i, j): #think the problem might be the -1 j value.
                if self.data[i] == value:
                    return i

        raise ValueError
                          
    def count(self, value):
        """Returns the number of times value appears in this list."""
        count = 0
        for i in range(len(self.data)):
            if self.data[i] == value:
                count += 1
        return count

    ### bulk operations ###

    def __add__(self, other):
        """Implements `self + other_array_list`. Returns a new ArrayList
        instance that contains the values in this list followed by those
        of other."""
        nsize = self.size + other.size
        narray = np.empty(nsize, dtype=object)

        for i in range(self.size):
            narray[i] = self.data[i]
        for i in range(other.size):
            narray[self.size + i] = other.data[i]

        return narray
            
    def clear(self):
        """Clear the ArrayList."""
        self.data = np.empty(0, dtype=object)
        self.size = 0

        #return self.data

    def copy(self):
        """Returns a new ArrayList instance (with a separate data store), that
        contains the same values as this list."""
        narray = np.empty(self.size, dtype=object)

        for i in range(len(self.data)):
            narray[i] = self.data[i]

        return narray

    def extend(self, other):
        """Adds all elements, in order, from other --- an Iterable --- to this 
        list."""
        nsize = self.size + len(other)
        narray = np.empty(nsize, dtype=object)

        for i in range(self.size):
            narray[i] = self.data[i]
        for i in range(len(other)):
            narray[self.size + i] = other[i]

        return narray

