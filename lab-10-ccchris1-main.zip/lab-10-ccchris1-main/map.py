from typing import Any, Iterator

class BSTree:
    class Node:
        def __init__(self, key, val, left=None, right=None):
            self.key = key
            self.val = val
            self.left = left
            self.right = right


    def __init__(self):
        self.size = 0
        self.root = None


    def __getitem__(self, key: Any) -> Any:
        def getting(node):
            if key not in self:
                raise KeyError
            if not node:
                raise KeyError
            elif key < node.key:
                return getting(node.left)
            elif key > node.key:
                return getting(node.right)
            else:
                return node.val
            
        
        return getting(self.root)
            
    

    def __setitem__(self, key: Any, val: Any) -> None:
        #assert key, val not in self
        def set(node):
            if not node:
                return BSTree.Node(key, val)
            elif key < node.key:
                node.left = set(node.left)
            elif key > node.key:
                node.right = set(node.right)
            else:
                node.val = val #key already exists, just update val
            
            return node
            
        self.root = set(self.root)
        self.size += 1
        

    def __delitem__(self, key: Any) -> None:
        assert(key in self)
        def delitem_rec(node):
            if key < node.key:
                node.left = delitem_rec(node.left)
                return node
            elif key > node.key:
                node.right = delitem_rec(node.right)
                return node
            else:
                if not node.left and not node.right:
                    return None
                elif node.left and not node.right:
                    return node.left
                elif node.right and not node.left:
                    return node.right
                else:
                    t = node.left
                    if not t.right:
                        node.key = t.key
                        node.left = t.left
                    else:
                        n = t
                        while n.right.right:
                            n = n.right
                        t = n.right
                        n.right = t.left
                        node.key = t.key
                    return node
                
        self.root = delitem_rec(self.root)
        self.size -= 1


    def __contains__(self, key: Any) -> bool:
        def find(node):
            if not node:
                return False
            elif key < node.key:
                return find(node.left)
            elif key > node.key:
                return find(node.right)
            else:
                return True
        
        return find(self.root)


    def __len__(self) -> int:
        return self.size
    

    def __iter__(self) -> Iterator[Any]:
        def iter_rec(node):
            if node:
                yield from iter_rec(node.left)
                yield node.key
                yield from iter_rec(node.right)
                    
        return iter_rec(self.root)


    def keys(self) -> Iterator[Any]:
        def iter_rec(node):
            if node:
                yield from iter_rec(node.left)
                yield node.key
                yield from iter_rec(node.right)
                    
        return iter_rec(self.root)


    def values(self) -> Iterator[Any]:
        def iter_rec(node):
            if node:
                yield from iter_rec(node.left)
                yield node.val
                yield from iter_rec(node.right)
                    
        return iter_rec(self.root)


    def items(self) -> Iterator[tuple[Any,Any]]:
        def iter_rec(node):
            if node:
                yield from iter_rec(node.left)
                yield ((node.key, node.val))
                yield from iter_rec(node.right)
                    
        return iter_rec(self.root)

