[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/GOlXqi1g)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=16224615)
# Lab: Linked List

## Overview

For this assignment you will complete the implementation of the linked list data structure (`LinkedList`), so that it supports (nearly) all the [common](https://docs.python.org/3/library/stdtypes.html#common-sequence-operations) and [mutable](https://docs.python.org/3/library/stdtypes.html#mutable-sequence-types) sequence operations. You will also be adding APIs for *cursor-driven* operations, which allow for better performance than the more familiar index-driven ones.

Your implementation should make use of doubly-linked nodes (i.e., each containing a `prior` and `next` reference), an ever-present `sentinel (head)` node (to simplify edge cases), and a "circular" topology (where the head and tail nodes are neighbors). A `sentinel` node is a dummy node that goes at the front of a list, which is never to be deleted. In a doubly-linked list, the sentinel node points to the first and last elements of the list. This node should not be counted as part of the index i.e., `head.next` is the node with `index = 0`.

## Implementation Details

As with the previous assignment, we've partitioned the `LinkedList` methods you need to implement (and the corresponding test cases that follow) into categories:

1. Subscript-based access [6 points]
2. Cursor-based access [6 points]
3. Iteration [3 points]
4. Stringification [2 point]
5. Single-element manipulation [6 points]
6. Predicates (True/False queries) [5 points]
7. Queries [6 points]
8. Bulk operations [6 points]

All your code will go in `linkedlist.py`, where you will find stubs for all the methods you need to implement, along with further documentation. You may add additional private methods if you find it helpful to do so.

Besides (2), you should be familiar with the APIs from all the other categories, as you implemented them for the previous lab. The cursor-based methods are detailed in the next section.

## Cursor-based access

A cursor-driven API makes sense for a linked list, as it allows us to avoid repeated $O(N)$ indexing when manipulating adjacent elements.

The cursor-based APIs you will implement are as follows:

- `cursor_get`: retrieves the value at the current cursor position (if valid)
- `cursor_set`: sets the cursor to the node at the provided index
- `cursor_move`: moves the cursor forward or backward by the provided offset (a positive or negative integer);  note that it is possible to advance the cursor past the beginning or end of the list, in which case the cursor will just "wrap around", skipping over the head node
- `cursor_insert`: inserts a new value after the cursor and sets the cursor to the new node
- `cursor_delete`: deletes the node the cursor refers to and sets the cursor to the following node
