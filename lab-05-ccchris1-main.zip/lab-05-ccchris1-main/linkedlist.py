class LinkedList:
    class Node:
        def __init__(self, val, prior=None, next=None):
            self.val = val
            self.prior = prior
            self.next  = next
    
    def __init__(self):
        self.head = LinkedList.Node(None) # head node (never to be removed)
        self.head.prior = self.head.next = self.head # "circular" topology
        self.cursor = self.head
        self.length = 0
                
    def prepend(self, value):
        n = LinkedList.Node(value, prior=self.head, next=self.head.next)
        self.head.next.prior = self.head.next = n
        self.length += 1
        
    def append(self, value):
        n = LinkedList.Node(value, prior=self.head.prior, next=self.head)
        n.prior.next = n.next.prior = n
        self.length += 1
            
            
    ### subscript-based access ###
    
    def __getitem__(self, idx):
        """Implements `x = self[idx]`"""
        if idx < 0:
            idx = self.length + idx
        if idx >= self.length or idx < 0:
            raise IndexError()
        current = self.head.next
        i = 0
        while i < idx:
            current = current.next
            i += 1
        return current.val

    def __setitem__(self, idx, value):
        """Implements `self[idx] = x`"""
        if idx < 0:
            idx = self.length + idx
        if idx >= self.length or idx < 0:
            raise IndexError()
        current = self.head.next
        i = 0
        while i < idx:
            current = current.next
            i += 1
        current.val = value
        return current.val

    def __delitem__(self, idx):
        """Implements `del self[idx]`"""
        if idx < 0:
            idx = self.length + idx
        if idx >= self.length or idx < 0:
            raise IndexError()
        current = self.head.next
        i = 0
        while i < idx:
            current = current.next
            i += 1
        current.prior.next = current.next
        current.next.prior = current.prior
        current = current.next
        self.length -= 1

        
    ### cursor-based access ###

    def normalize_idx(self, idx):
        newIdx = idx
        if newIdx < 0:
            newIdx += len(self)
            if newIdx < 0:
                newIdx = 0
        return newIdx
    
    def cursor_get(self): 
        """retrieves the value at the current cursor position"""
        assert self.cursor is not self.head
        assert self.cursor is not None
        return self.cursor.val

    def cursor_set(self, idx): 
        """sets the cursor to the node at the provided index"""
        idx = self.normalize_idx(idx)
        cur = self.head.next
        for i in range(idx):
            cur = cur.next
        self.cursor = cur

    def cursor_move(self, offset): 
        """moves the cursor forward or backward by the provided offset (a 
        positive or negative integer);  note that it is possible to advance the
        cursor past the beginning or end of the list, in which case the cursor 
        will just "wrap around", skipping over the head node"""
        assert len(self) > 0
        if self.cursor is None: 
            self.cursor = self.head.next
        assert len(self) > 0
        if offset > 0: 
            for i in range(offset):
                self.cursor = self.cursor.next 
                if self.cursor is self.head: 
                    self.cursor = self.cursor.next
        
        else:
            for i in range(abs(offset)):
                self.cursor = self.cursor.prior
                if self.cursor is self.head:
                    self.cursor = self.cursor.prior

    def cursor_insert(self, value): 
        """inserts a new value after the cursor and sets the cursor to the 
        new node"""
        newNode = self.Node(value, prior=self.cursor, next=self.cursor.next)
        self.cursor.next = newNode
        newNode.next.prior = newNode
        newNode.prior.next = newNode
        self.length += 1

        self.cursor = newNode

    def cursor_delete(self):
        """deletes the node the cursor refers to and sets the cursor to the 
        following node"""
        assert self.cursor is not self.head and len(self) > 0, "Cursor is invalid or the list is empty."

        current_cursor = self.cursor

        if current_cursor.next is self.head: 
            self.cursor = self.head.next  
        else:
            self.cursor = self.cursor.next  

        current_cursor.prior.next = current_cursor.next
        current_cursor.next.prior = current_cursor.prior
        
        self.length -= 1

    
    ### iteration ###

    def __iter__(self):
        """Supports iteration (via `iter(self)`)"""
        current = self.head.next
        while current and current.val != None:
            yield current.val
            current = current.next

    
    ### stringification ###
    
    def __str__(self):
        """Implements `str(self)`. Returns '[]' if the list is empty, else
        returns `str(x)` for all values `x` in this list, separated by commas
        and enclosed by square brackets. E.g., for a list containing values
        1, 2 and 3, returns '[1, 2, 3]'."""
        if self.length > 0:
            string = [self[i] for i in range(self.length)]
            return str(string)
        else:
            string = "[]"
            return string
        
    def __repr__(self):
        """Implements `repr(self)`. Similar to `__str__`, but represents the
        list as an expression that could be evaluated to reproduce the list."""
        if self.length > 0:
            string = [self[i] for i in range(self.length)]
            return str(string)
        else:
            string = "[]"
            return string


    ### single-element manipulation ###
        
    def insert(self, idx, value):
        """Inserts value at position idx, shifting the original elements down 
        the list, as needed. Note that inserting a value at len(self) --- 
        equivalent to appending the value --- is permitted. Raises IndexError 
        if idx is invalid."""
        idx = self.normalize_idx(idx)
        if idx > self.length:
            raise IndexError()
        if idx == self.length:
            self.append(value)

        cur = self.head.next
        for i in range(idx):
            cur = cur.next
        newNode = self.Node(value, prior=cur.prior, next=cur)
        cur.prior.next = newNode
        cur.prior = newNode

        self.length += 1
    
    def pop(self, idx=-1):
        """Deletes and returns the element at idx (which is the last element,
        by default)."""
        if idx < 0:
            idx = idx + self.length
        if idx >= self.length or idx < 0:
            raise IndexError()
        
        cur = self.head.next
        for i in range(idx):
            cur = cur.next
        deletedNode = cur
        cur.prior.next = cur.next
        cur.next.prior = cur.prior
        cur = cur.next
        
        self.length -= 1
        
        return deletedNode.val
    
    def remove(self, value):
        """Removes the first (closest to the front) instance of value from the
        list. Raises a ValueError if value is not found in the list."""
        check = False
        cur = self.head.next
        for i in range(self.length):
            if cur.val == value:
                idxtorem = i
                check = True
                break
            cur = cur.next
        
        if check == True:
            del self[idxtorem]
        else:
            raise ValueError
    

    ### predicates (T/F queries) ###
    
    def __eq__(self, other):
        """Returns True if this LinkedList contains the same elements (in 
        order) as other. If other is not an LinkedList, returns False."""
        if self.length != other.length:
            return False
        if self.length == 0 and other.length == 0:
            return True
        for i in range(self.length):
            if self[i] == other[i]:
                return True
        return False

    def __contains__(self, value):
        """Implements `val in self`. Returns true if value is found in this
        list."""
        if value == None:
            return False
        cur = self.head.next
        for i in range(self.length):
            cur = cur.next
            if cur.val == value:
                return True

        return False


    ### queries ###
    
    def __len__(self):
        """Implements `len(self)`"""
        return self.length
    
    def min(self):
        """Returns the minimum value in this list."""
        return min(self)
    
    def max(self):
        """Returns the maximum value in this list."""
        return max(self)
    
    def index(self, value, i=0, j=None):
        """Returns the index of the first instance of value encountered in
        this list between index i (inclusive) and j (exclusive). If j is not
        specified, search through the end of the list for value. If value
        is not in the list, raise a ValueError."""
        if j == None:
            for i in range(i, self.length):
                if self[i] == value:
                    return i
        if value not in self:
            raise ValueError()
        else:
            if j < 0:
                j = j + self.length
            if j >= self.length or j < 0:
                raise ValueError()
            for i in range(i,j):
                if self[i] == value:
                    return i
        raise ValueError()
    
    def count(self, value):
        """Returns the number of times value appears in this list."""
        count = 0
        for i in range(self.length):
            if self[i] == value:
                count += 1
        return count

    
    ### bulk operations ###

    def __add__(self, other):
        """Implements `self + other_list`. Returns a new LinkedList
        instance that contains the values in this list followed by those 
        of other."""
        lst = LinkedList()
        for i in self:
            lst.append(i)
        for j in other:
            lst.append(j)
        return lst
    
    def clear(self):
        """Removes all elements from this list."""
        self.length = 0
        self.head.prior = self.head.next = self.head
        
    def copy(self):
        """Returns a new LinkedList instance (with separate Nodes), that
        contains the same values as this list."""
        lst = LinkedList()
        for i in self:
            lst.append(i)
        return lst

    def extend(self, other):
        """Adds all elements, in order, from other --- an Iterable --- to this
        list."""
        for i in other:
            self.append(i)

        return self
