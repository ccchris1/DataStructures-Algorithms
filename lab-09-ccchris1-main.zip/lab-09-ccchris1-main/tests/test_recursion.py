import pytest
from recursion import (super_digit, pascal, can_make_product, 
                       number_ties, deciding_votes_per_block)

@pytest.mark.points(5)
def test_exercise1():
    assert super_digit(5) == 5
    assert super_digit(30) == 3
    assert super_digit(9876) == 3
    assert super_digit(11111111111111) == 5
    assert super_digit(12345678901234567890) == 9


@pytest.mark.points(5)
def test_exercise2():
    assert pascal(0, 0) == 1
    assert pascal(1, 0) == 1
    assert pascal(2, 1) == 2
    assert pascal(5, 1) == 5
    assert pascal(5, 2) == 10
    assert pascal(10, 5) == 252


@pytest.mark.points(5)
def test_exercise3():
    assert can_make_product(10, [2, 5])
    assert can_make_product(10, [2, 3, 4, 5])
    assert can_make_product(10, [3, 4, 2, 5])
    assert can_make_product(10, [10])
    assert can_make_product(81, [2, 2, 3, 3, 4, 9])
    assert can_make_product(66402, [2, 4, 5, 12, 17, 25, 31, 63])
    assert not can_make_product(10, [2, 2, 2, 4])
    assert not can_make_product(243, [2, 2, 3, 3, 3, 4, 4, 4])
    assert not can_make_product(81, [2, 3, 5, 9, 11])
    assert not can_make_product(100, [3, 4, 5, 8, 10])
    assert not can_make_product(12369, [3, 4, 5, 8, 19, 20, 31])


@pytest.mark.points(5)
def test_exercise4():
    assert number_ties([1, 2, 3]) == 2
    assert number_ties([1, 1, 2, 3, 5]) == 4
    assert number_ties([4, 5, 6, 7, 8, 9]) == 0
    assert number_ties([10, 15, 9, 4, 4, 8, 12, 8]) == 10
    assert number_ties([17, 10, 9, 9, 10, 10, 7, 12, 17, 13, 14, 9, 16, 16, 5]) == 554
    assert number_ties([16, 17, 17, 30, 15, 27, 22, 20, 33, 33, 26, 22, 27, 19, 15, 16, 25, 25, 19, 18]) == 8040


@pytest.mark.points(5)
def test_exercise5():
    assert deciding_votes_per_block([1, 1, 2]) == [2, 2, 4]
    assert deciding_votes_per_block([1, 2, 3, 4]) == [2, 4, 4, 6]
    assert deciding_votes_per_block([4, 5, 6, 7, 8, 9]) == [4, 8, 8, 12, 12, 16]
    assert deciding_votes_per_block([10, 15, 9, 4, 4, 8, 12, 8]) == [40, 70, 40, 20, 20, 34, 50, 34]
    assert deciding_votes_per_block([17, 10, 9, 9, 10, 10, 7, 12, 17, 13, 14, 9, 16, 16, 5]) == [5112, 3040, 2750, 2750, 3040, 3040, 2172, 3578, 5112, 3886, 4200, 2750, 4792, 4792, 1626]
