[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/QxdVy-Sp)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=16979809)
# Lab: Recursion


## Overview

In this lab you will solve a number of problems that are a natural fit for recursive solutions. It is up to you to determine the base cases and recursive cases for each problem. As always, we provide you with the function declarations whose bodies you must complete, but for this assignment you may find it helpful to define additional helper functions (which may be recursive).


## Exercises

All the exercises in this assignment will have you making edits to `recursion.py`.

### Exercise 1: The Super Digit (5 points)

The "super digit" of a (base 10) number *N* is defined as follows:
- if the number consists of a single digit, it is simply *N*
- otherwise, it is the super digit of the sum of the digits of *N*

Examples:
- the super digit of 7 is 7
- the super digit of 42 is the super digit of 4+2=6, which is 6
- the super digit of 9876 is the super digit of 9+8+7+6=30, which is the super digit of 3+0=3, which is 3

Complete the function `super_digit`, which returns the super digit of its argument.


### Exercise 2: Pascal's Triangle (5 points)

Pascal's triangle is a triangular arrangement of numbers where the top row contains the single number `1`, and the values in each following (centered) row are the sum of the value(s) in the row above. The following first five rows of Pascal's triangle should help demonstrate the idea:

              1
             1 1
            1 2 1
           1 3 3 1
          1 4 6 4 1
      
By convention, the rows and columns of Pascal's triangle are numbered starting from 0 — note that the 0th column of every row contains the value 1. Row 1 has two values, both of which are 1; row 2 has three values, with column 1 being 2, and so on.

To synthesise the values in Pascal's triangle, we can use the following recursive formula:

$$
\text{pascal}(r, c) = \begin{cases}
1 & \text{if } c = 0 \text{ or } c = r \\
\text{pascal}(r-1, c-1) + \text{pascal}(r-1, c) & \text{otherwise}
\end{cases}
$$

where $r$ is the row number and $c$ is the column number (both 0-indexed).

Complete the function `pascal`, which returns the value to be found in a given row and column of Pascal's triangle.


### Exercise 3: Subset Product (5 points)

This next one asks you to employ a common recursive pattern — that of computing all the subsets of a given set of things. In this problem, you are to determine whether or not an integer $P > 1$ can be computed as the product of any combination of a provided list of integers (where each factor $f > 0$ can only be used once).

Examples:

- given $P = 10$, and the list [2, 3, 4, 5], we see that $2 \times 5 = 10$, so the answer is yes
- given $P = 81$, and the list [2, 2, 3, 3, 4, 9], $3 \times 3 \times 9 = 81$, so the answer is yes
- given $P = 100$ and the list [3, 4, 5, 8, 10], the answer is no

Complete the function `can_make_product`, which returns `True` or False based on whether the argument `p` can be computed as the product of some subset of the list of integers `vals`.


### Exercise 4: Block Voting Systems Part 1 - Ties (5 points)

In voting systems such as the United States' electoral college, voters are assigned different weights which we'll refer to as voting "blocks". This makes it so that a given voter may have a greater or lesser impact on the  outcome of a vote.

There are a few different ways of measuring the effectiveness of a block voting system. You'll write a couple of recursion functions to help do this.

To start, it's interesting to determine the number of ways in which a block voting system can be tied. Consider a system of 3 voting blocks: block A = 3 votes, block B = 2 votes, block C = 1 vote. The following are tie situations where each block can vote either *for* or *against* some measure:

- A *for* vs. B + C *against* (3 vs. 2 + 1)
- B + C *for* vs. A *against* (2 + 1 vs. 3)

With the list of voting blocks [1, 1, 2, 3, 5], on the other hand, there are a total of 4 possible tied scenarios (you should be able to enumerate them).

Complete the function `number_ties`, which returns the number of tie situations arising from the provided list of voting blocks. Note that we've also include two default arguments that you may find useful in your implementation — feel free to change their names and/or initial values (or add additional arguments with default values). 


### Exercise 5: Block Voting Systems Part 2 - The Deciding Vote (5 points)

More important than determining how and when ties can occur in a block voting system, we can also determine how many situations arise in which a given block can cast the *deciding vote*.

E.g., given voting blocks [1, 2, 3, 4], to determine the number of times the last block casts the deciding vote, we observe that:

- there are a total of eight ways in which blocks 1, 2, and 3 can vote:
    1. 1 + 2 + 3 (for) vs. 0 (against)
    2. 1 + 2 (for) vs. 3 (against)
    3. 1 + 3 (for) vs. 2 (against)
    4. 1 (for) vs. 2 + 3 (against)
    5. 2 + 3 (for) vs. 1 (against)
    6. 2 (for) vs. 1 + 3 (against)
    7. 3 (for) vs. 1 + 2 (against)
    8. 0 (for) vs. 1 + 2 + 3 (against)

- in cases 2-7, the last voter (with a block of 4 votes) can cause the result to swing one way or the other (or end in a tie); we therefore say that the last block has the deciding vote in *6* cases

If you repeat the analysis for blocks 1, 2, and 3, you'll find that they are the deciding voters in 2, 4, and 4 cases, respectively (meaning that the blocks with 2 and 3 votes are equally important!).

Complete the function `deciding_votes_per_block`, which will take a list of voting blocks and return a list of times that each block is the deciding vote. You may wish to define a separate helper function that computes the number of deciding votes for a given block.
