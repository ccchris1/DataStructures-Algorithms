# Exercise 1: The Super Digit
def super_digit(n: int) -> int:
    if n < 10:
        return n
    else:
        total = 0
        while n > 0:
            total += n % 10
            n //= 10
        return super_digit(total)


# Exercise 2: Pascal's Triangle
def pascal(row: int, column: int) -> int:
    if column == 0 or column == row:
        return 1
    else:
        return pascal(row - 1, column - 1) + pascal(row - 1, column)


# Exercise 3: Subset Product
def can_make_product(p: int, vals: list[int]) -> bool:
    if p == 1: 
        return True
    if not vals:  
        return False

    if vals[0] <= p and p % vals[0] == 0:  
        if can_make_product(p // vals[0], vals[1:]):  
            return True

    return can_make_product(p, vals[1:])  


# Exercise 4: Block Voting Systems Part 1 - Ties
def number_ties(blocks: list[int], for_votes=0, against_votes=0) -> int:
    if not blocks and for_votes==against_votes:
        return 1
    elif not blocks:
        return 0
    else:
        num = blocks[0]
        return number_ties(blocks[1:],for_votes+num,against_votes) + number_ties(blocks[1:],for_votes,against_votes+num)


# Exercise 5: Block Voting Systems Part 2 - The Deciding Vote 
def deciding_count(blocks1,tocheck, for_votes=0, against_votes=0):
    if not blocks1 and ((tocheck + for_votes) < against_votes or (tocheck+against_votes) < for_votes):
        return 0
    elif not blocks1:
        if ((tocheck+for_votes) >= against_votes ) or ((tocheck+against_votes) >= for_votes):
            return 1
    else:
        num=blocks1[0]
        return deciding_count(blocks1[1:],tocheck,for_votes+num,against_votes) + deciding_count(blocks1[1:],tocheck,for_votes,against_votes+num)

def deciding_votes_per_block(blocks):
    to_return=[]
    for i in range(len(blocks)):
        tocheck=blocks.pop()
        to_return.append(deciding_count(blocks,tocheck))
        blocks.insert(0, tocheck)
    to_return.reverse()
    return to_return
